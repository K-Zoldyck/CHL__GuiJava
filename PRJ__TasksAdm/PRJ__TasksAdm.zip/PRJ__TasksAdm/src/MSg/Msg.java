
package MSg;
public class Msg {
    public static String ct_criada() {return "Categoria criada";}
    public static String ct_dpicad() {return "Essa categoria já foi registrada !!";}
    
    public static String tf_criada() {return "Tarefa criada";}
    public static String tf_dpicad() {return "Essa tarefa já foi registrada !!";}
    public static String tf_modificada() {return "Tarefa atualizada";}
    public static String tf_removida() {return "Tarefa removida";}
}
