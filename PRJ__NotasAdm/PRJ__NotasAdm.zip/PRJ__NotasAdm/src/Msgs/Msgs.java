
package Msgs;
public class Msgs {
    public static String erro_1() {return "Disciplina já cadastrada";}
}
